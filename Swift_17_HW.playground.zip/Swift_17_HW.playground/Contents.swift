
/* Шахматная доска (Легкий уровень)  - выполнен полностью
 
 1. Создайте тип шахматная доска.
 
 2. Добавьте сабскрипт, который выдает цвет клетки по координате клетки (буква и цифра).
 
 3. Если юзер ошибся координатами - выдавайте нил
 
 Крестики нолики (Средний уровень) - выполнен полностью
 
 1. Создать тип, представляющий собой поле для игры в крестики нолики
 На каждой клетке может быть только одно из значений: Пусто, Крестик, Нолик
 Добавьте возможность красиво распечатывать поле
 
 2. Добавьте сабскрипт, который устанавливает значение клетки по ряду и столбцу,
 причем вы должны следить за тем, чтобы программа не падала если будет введен не существующий ряд или столбец.
 
 3. Также следите за тем, чтобы нельзя было устанавливать крестик либо нолик туда, где они уже что-то есть. Добавьте метод очистки поля.
 
 4. Если хотите, добавте алгоритм, который вычислит победителя - не добавлено
 
 Морской бой (Тяжелый уровень) - сделан не полностью
 
 1. Создайте тип корабль, который будет представлять собой прямоугольник. В нем может быть внутренняя одномерная система координат (попахивает сабскриптом). Корабль должен принимать выстрелы по локальным координатам и вычислять когда он убит
 
 2. Создайте двумерное поле, на котором будут располагаться  корабли врага. Стреляйте по полю и подбейте вражеский четырех трубник :)
 
 3. Сделайте для приличия пару выстрелов мимо, красивенько все выводите на экран :)
 */
//1
enum Color {
    case White
    case Black
}

struct Desk {
    var size: Int
    subscript (coordinates:(String,Int)) -> Color? {
        let alf = "abcdefghijklmnopqrstuvwxyz"
        var x = [String]()
        var count = 0
        for i in alf {
            if count < size {
                x.insert(String(i),at:count)
                count += 1
            }
        }
        let uperCoord = coordinates.0.lowercased()
        if x.contains(uperCoord) && (coordinates.1 > 0 && coordinates.1 <= size) {
            if ((x.index(of: uperCoord))! + coordinates.1) % 2 == 0 {
                return Color.Black
            } else {
                return Color.White
            }
        }
        return nil
    }
}
var poz1 = Desk(size: 10)
poz1[("f",5)]


//2
print("_______PART 2________")
enum TicTak:String {
    case Block = "\u{2B1C}"
    case Cross = "\u{274C}"
    case Zero = "\u{2B55}"
}
class ticTacDesk {
    var desk = [[TicTak]]()
    init() {
        let x = Array(repeating: (TicTak.Block), count: 3)
        self.desk = Array(repeating: x, count: 3)
    }
    
    var isEmpty = true
    //метод вывода на экран доски
    func printDesk () {
        for i in self.desk {
            var str = ""
            for j in i {
                str += j.rawValue
            }
            print (str)
        }
    }
    // метод очистки ячеек
    func remove () {
        for i in 0...2{
            for j in 0...2{
                self.desk[i][j] = TicTak.Block
            }
        }
    }
    //проверка на попадание в зону клеток
    func test1 (_ row:Int,_ coloumn:Int) -> Bool {
        return (row >= 0 && row <= 2 && coloumn >= 0 && coloumn <= 2)
    }
    
    //проверка на открытость блока
    func test2 (_ row:Int, _ coloumn:Int) -> Bool {
        return (self.desk[row][coloumn] == TicTak.Block)
    }
    
    //Сабскрипт установки значения в клетку
    subscript (row:Int, coloumn:Int) -> Any {
        get {
            if test1(row, coloumn) {
                if test2(row, coloumn) {
                    if isEmpty == true {
                        self.desk[row][coloumn] = TicTak.Cross
                        isEmpty = false
                        return self.desk
                    } else if isEmpty == false {
                        self.desk[row][coloumn] = TicTak.Zero
                        isEmpty = true
                        return self.desk
                    } else {
                        return self.desk
                    }
                } else {
                    print ("This cell is busy, select another value")
                    return self.desk
                }
            } else {
                print ("Selected not to the zone")
                return self.desk
            }
        }
    }
}
var desk = ticTacDesk()
desk.printDesk()
desk[1,1]
desk.printDesk()
desk[1,4]
desk[1,2]
desk.printDesk()
desk[1,2]
desk.printDesk()
desk.remove()
desk.printDesk()
//3
print("_______PART 3________")
//возможные виды корабля
enum ShipView:String {
    case Full = "\u{2B1B}"
    case Injured = "\u{1F525}"
    case Dead = "\u{2693} "
}
//создаем класс корабля
class Ship {
    
    var length: [ShipView]
    init (length:Int) {
        self.length = Array(repeating: ShipView.Full, count: length)
    }
    subscript (localcoordinate:Int) -> Any {
        get {
            if (localcoordinate < self.length.count && localcoordinate >= 0)
            {
                self.length[localcoordinate] = ShipView.Injured
                if !self.length.contains(ShipView.Full)
                {
                    for i in 0..<self.length.count
                    {
                        self.length[i] = ShipView.Dead
                    }
                    return self.length
                } else {return self.length}
            } else {return self.length}
        }
    }
}
var ship = Ship(length: 4)
ship[3]
ship[2]
ship[1]
ship[0]
//Возможные виды моря
enum SeaView:String {
    case first = "\u{2B1C}"
    case past = "\u{1F30A}"
}
//Создаем класс море
class ShipDesk {
    enum Orientation {
        case isHorizontal
        case isVertical
    }
    var sea = [[SeaView]]()
    var length:Int
    var width:Int
    init (length:Int,width:Int) {
        self.length = length < 2 ? 2 : length
        self.width = width < 2 ? 2 : width
        let x = Array(repeating: (SeaView.first), count: self.length)
        self.sea = Array(repeating: x, count: self.width)
    }
    //метод вывода на экран моря
    func printDesk () {
        for i in self.sea {
            var str = ""
            for j in i {
                str += j.rawValue
            }
            print (str)
        }
    }
}
var sea = ShipDesk(length: 10, width: 10)
sea.printDesk()
