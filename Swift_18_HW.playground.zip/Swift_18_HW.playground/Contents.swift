//Home work Alexey Skuturenko 18: Nasledovanie

/*
 1. У нас есть базовый клас "Артист" и у него есть имя и фамилия. И есть метод "Выступление". У каждого артиста должно быть свое выступление: танцор танцует, певец поет и тд. А для художника, что бы вы не пытались ставить, пусть он ставит что-то свое (пусть меняет имя на свое артистическое). Когда вызываем метод "выступление" показать в консоле имя и фамилию артиста и собственно само выступление.
 Полиморфизм используем для артистов. Положить их всех в массив, пройтись по нему и вызвать их метод "выступление"
 
 2. Создать базовый клас "транспортное средство" и добавить три разных проперти: скорость, вместимость и стоимость одной перевозки (computed). Создайте несколько дочерних класов и переопределите их компютед проперти у всех. Создайте класс самолет, корабль, вертолет, машина и у каждого по одному объекту. В компютед пропертис каждого класса напишите свои значения скорости, вместимости, стоимости перевозки. + у вас должен быть свой метод который считает сколько уйдет денег и времени что бы перевести из пункта А в пункт В определенное количество людей с использованимем наших транспортных средств. Вывести в кольсоль результат (как быстро сможем перевести, стоимость, количество перевозок).
 Используем полиморфизм
 
 3. Есть 5 классов: люди, крокодилы, обезьяны, собаки, жирафы. (в этом задании вы будете создавать не дочерние классы, а родительские и ваша задача создать родительский таким образом, что бы группировать эти 5).
 - Создайте по пару объектов каждого класса.
 - Посчитайте присмыкающихся (создайте масив, поместите туда присмыкающихся и скажите сколько в нем объектов)
 - Сколько четвероногих?
 - Сколько здесь животных?
 - Сколько живых существ?
*/
//PART1
print ("______PART 1_______")
class Artist {
    var name:String
    var surName:String
    var fullName:String {
        return name + " " + surName
    }
    func action()-> String {
        return "I " + fullName + " and I'm artist"
    }
    init(name:String,surName:String) {
        self.name = name
        self.surName = surName
    }
}
class Dancer:Artist {
    override func action() -> String {
        return "I " + fullName + " and I'm dancer"
    }
}
class Singer:Artist {
    override func action() -> String {
        return "I " + fullName + " and I'm singer"
    }
}
class Painter:Artist{
    override var fullName: String{
        return String(name.first!) + String(surName.first!)
        }
    override func action() -> String {
        return "I " + fullName + " and I'm painter"
    }
}

var artist1 = Artist(name: "Pier", surName: "Rishar")
var dancer1 = Dancer(name: "Anastasiya", surName: "Volochkova")
var singer1 = Singer(name: "Jerrard", surName: "Leto")
var painter = Painter(name: "Alex", surName: "Bonopart")
var artistArray:[Artist] = []
artistArray.append(artist1)
artistArray.append(dancer1)
artistArray.append(singer1)
artistArray.append(painter)
for artist in artistArray {
    print (artist.action())
}
//PART1
print ("______PART 2_______")
class Artist {
