//2 часть задания по Наследованию
/*
 2. Создать базовый клас "транспортное средство" и добавить три разных проперти: скорость, вместимость и стоимость одной перевозки (computed). Создайте несколько дочерних класов и переопределите их компютед проперти у всех. Создайте класс самолет, корабль, вертолет, машина и у каждого по одному объекту. В компютед пропертис каждого класса напишите свои значения скорости, вместимости, стоимости перевозки. + у вас должен быть свой метод который считает сколько уйдет денег и времени что бы перевести из пункта А в пункт В определенное количество людей с использованимем наших транспортных средств. Вывести в кольсоль результат (как быстро сможем перевести, стоимость, количество перевозок).
 Используем полиморфизм
 */

import Foundation
class Transport {
    var name:String {
        return "Transport"
    }
    var speed: Double {
        return 0
    }
    var capacity: Int {
        return 0
    }
    var cost: Double {
        return 1
    }
    func calculateCost (distance:Double,countPerson:Int) -> (cost:Double, time: Double, count: Int) {
        let countTrip = lround(Double(countPerson/capacity)) + 1
        let time = distance/speed
        let totalTimeTrip = Double(countTrip) * time
        let totalCost = Double(countTrip) * cost
        return (totalCost, totalTimeTrip, countTrip)
    }
}

class Airplane:Transport {
    override var name:String {
        return "Airplane"
    }
    override var speed: Double {
        return 500
    }
    override var capacity: Int {
        return 78
    }
    override var cost: Double {
        return 3500
    }
}
class Helicopter:Transport {
    override var name:String {
        return "Helicopter"
    }
    override var speed: Double {
        return 300
    }
    override var capacity: Int {
        return 6
    }
    override var cost: Double {
        return 6000
    }
}
class Ship:Transport {
    override var name:String {
        return "Ship"
    }
    override var speed: Double {
        return 100
    }
    override var capacity: Int {
        return 400
    }
    override var cost: Double {
        return 600
    }
}
class Car:Transport {
    override var name:String {
        return "Car"
    }
    override var speed: Double {
        return 160
    }
    override var capacity: Int {
        return 4
    }
    override var cost: Double {
        return 300
    }
}
var airplane = Airplane()
var helicopter = Helicopter()
var ship = Ship()
var car = Car()
var arrayTransport:[Transport] = []
arrayTransport.append(airplane)
arrayTransport.append(helicopter)
arrayTransport.append(ship)
arrayTransport.append(car)
for transoprt in arrayTransport {
    let result = transoprt.calculateCost(distance: 650, countPerson: 1_800_000)
    print ("Transport \(transoprt.name), shipping cost - \(result.cost), time - \(result.time), count - \(result.count)")
}
