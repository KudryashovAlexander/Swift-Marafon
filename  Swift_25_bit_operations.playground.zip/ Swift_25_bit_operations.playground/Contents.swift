//Битовые операции Алексей Скутуренко занятие 25
extension UInt8 {
//extension Int8 {
    func binary() -> String {
        var result = ""
        for i in 0..<8 {
            let mask = 1 << i
            let set = Int(self) & mask != 0
            result = (set ? "1" : "0") + result
        }
        return result
    }
}


/*
// "<<" Оператор сдвига
var a: UInt8 = 57
//Максимальное число 255

//0b11111111
//Битовые операции в однобайтовом числе
a.binary()

a = 0b00111001
a.binary()
(5 as UInt8).binary()


a = a + 0b0000101
a.binary()
(4 as UInt8).binary()
a = a - 0b00000100

a.binary()
//a = a * 2 = ..
a = a << 1
//  можно сдвинуть мксимум на 8


a = a >> 1
a.binary()

a = a &* 8
// Оператор "&*" переполнения
a = 0b11111111
a = a &+ 1
*/
//для всех чисел
//var a: Int8 = 57
//a = 0b01111111
//a.binary()
//a = a &+ 1
//a.binary()
//
//a = 0
//a = a - 1
//a.binary()
//a = a - 1
//a.binary()
//a = 0b00100001
//a = a << 2
//a.binary()

//БИТОВЫЕ ОПЕРАЦИИ
var a: UInt8 = 0b00110011
var b: UInt8  = 0b11100001
//Битовое сложение
a.binary()
b.binary()
(a | b).binary()

//Битовое умножение
a.binary()
b.binary()
(a & b).binary()

//Исключающее сложение
a.binary()
b.binary()
(a ^ b).binary()

//Инверсия
a.binary()
(~a).binary()


a.binary()
b = 0b00010001
a.binary()
b.binary()
(a & b).binary()

b = 0b00000010
a.binary()
b.binary()
(a | b).binary()


a.binary()
b.binary()
(a ^ b).binary()


//сброс бита
b = 0b00010000
a.binary()
b.binary()
(a & ~b).binary()


enum CheckList: UInt8 {
    case Bread =    0b00000001
    case Chiken =   0b00000010
    case Apples =   0b00000100
    case Pears =    0b00001000
}
let checkList : UInt8 = 0b00001001
let bread = checkList & CheckList.Bread.rawValue
bread.binary()


/*
 Домашнее задание
 1. Расширьте енум из урока и добавьте в него метод, помогающий установить соответствующий бит в переданную маску и метод, помогающий его прочитать. Эти методы должны принимать и возвращать маску, либо принимать адрес маски и менять его
 
 2. Создать цикл, который будет выводить 1 байтное число с одним установленным битом в такой последовательности, чтобы в консоли получилась вертикальная синусоида
 
 3. Создайте 64х битное число, которое представляет клетки на шахматной доске. Установите биты так, что 0 - это белое поле, а 1 - черное. Младший бит это клетка а1 и каждый следующий байт начинается с клетки а (а2, а3, а4) и заканчивается клеткой h(h2, h3, h4). Выбирая клетки но индексу столбца и строки определите цвет клетки опираясь исключительно на значение соответствующего бита
 */
//1
extension CheckList {
    func setValue(value:CheckList, list: inout UInt8){
        list = value.rawValue | list
    }
    func getValue(value:CheckList, list: UInt8) -> Bool{
        return value.rawValue & list > 0
    }
}


//2
var numberfirst:UInt8 = 2
var check = true
for _ in 0..<16 {
    if numberfirst == 128 || numberfirst == 1 {
        check = !check
    }
    if check {
        numberfirst <<= 1
    } else {
        numberfirst >>= 1
    }
    print(numberfirst.binary())
}



//3
extension Int {
    func binary() -> String {
        var result = ""
        for i in 0..<64 {
            let mask = 1 << i
            let set = Int(self) & mask != 0
            result = (set ? "1" : "0") + result
        }
        return result
    }
}




//01010101
var number1 = 1
    //number1.binary()
for _ in 1..<4 {
    number1 = (number1 << 2) + 1
}
number1
number1.binary()
 //10101010
var number2 = 2
number2.binary()
for _ in 1..<4 {
    number2 = (number2 << 2) + 2
}
number2
number2.binary()

//64 битное число
var number = 0
for i in 1...8 {
    if i%2 == 1 {
        number = (number << 8) + number2
    } else {
        number = (number << 8) + number1
    }
}
number.binary()

func blackOrWhite (x: Int, y: Int) {
    let znach = (1<<(8*(8-y))) << x
    if number & znach > 0 {
        print ("Black")
    } else {
        print("White")
    }
}
blackOrWhite(x: 6, y: 3)
