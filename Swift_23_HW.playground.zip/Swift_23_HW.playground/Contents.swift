/*
 Сегодня будем строить свою небольшую социальную сеть.
 1. Сделать класс Человек, у этого класса будут проперти Папа, Мама, Братья, Сестры (всё опционально).
 Сделать примерно 30 человек, взять одного из них, поставить ему Папу/Маму. Папе и Маме поставить Пап/Мам/Братьев/Сестер. Получится большое дерево иерархии.
 Посчитать, сколько у этого человека двоюродных Братьев, троюродных Сестёр, Теть, Дядь, итд
 2. Все сестры, матери,... должны быть класса Женщина, Папы, братья,... класса Мужчины.
 У Мужчин сделать метод Двигать_диван, у Женщин Дать_указание (двигать_диван). Всё должно работать как и ранее.
 Всех этих людей положить в массив Семья, пройти по массиву посчитать количество Мужчин и Женщин, для каждого Мужчины вызвать метод Двигать_диван, для каждой женщины Дать_указание.
 3. Расширить класс человек, у него будет проперти Домашние_животные. Животные могут быть разные (попугаи, кошки, собаки...) их может быть несколько, может и не быть вообще.
 Раздать некоторым людям домашних животных. Пройти по всему массиву людей. Проверить каждого человека на наличие питомца, если такой есть - добавлять всех животных в массив животных. Посчитать сколько каких животных в этом массиве.
 Вся эта живность должна быть унаследована от класса Животные. У всех животных должен быть метод Издать_звук(крик) и у каждого дочернего класса этот метод переопределён на свой, т.е. каждое животное издаёт свой звук.
 Когда проходим по массиву животных, каждый представитель вида животных должен издать свой звук.
 
 Обязательно используем в заданиях Optional chaining и Type casting
 */


class Human {
    var name: String
    var father: Man?
    var mother: Woman?
    var brother: [Man]?
    var sister: [Woman]?
    var animal: [Animal]?
    init (name:String) {
        self.name = name
    }
}

class Man: Human{
   func move() {
        print("\(name) moving sofa")
    }
}
class Woman: Human{
    func tellMove() {
        print("\(name) tell move sofa")
    }
}



class Animal {
    var name: String
    init (name: String){
        self.name = name
    }
    func call(){
    }
}

class Parrot: Animal {
    override func call() {
        print("\(name): Popka durak")
    }
}
class Dog: Animal {
    override func call() {
        print("\(name): Gaf-Gaf-Gaf")
    }
}
class Cat: Animal {
    override func call() {
        print("\(name): Myau-Myau-Myau")
    }
}
class Pig: Animal {
    override func call() {
        print("\(name): Week-Week")
    }
}



var sasha = Man(name: "Sasha")
var tanya = Woman(name: "Tanya")
var vitya = Man(name: "Vitya")
var nadya = Woman(name: "Nadya")
var valya = Woman(name: "Valya")
var misha = Man(name: "Misha")
var olya = Woman(name: "Olya")
var fedya = Man(name: "Fedya")
var nina = Woman(name: "Nina")
var kolya = Man(name: "Kolya")
var elena = Woman(name: "Elena")
var alex1 = Man(name: "Alex")
var alex2 = Man(name: "Alexander")

var barsik = Dog(name: "Barsik")
var kesha = Parrot(name: "Kesha")
var borzik = Cat(name: "Borzik")
var gora = Pig(name: "Gora")
var bobik = Dog(name: "Bobik")

sasha.sister = [tanya]
sasha.animal = [borzik]
tanya.brother = [sasha]
tanya.animal = [barsik]
sasha.father = vitya
sasha.mother = nadya
tanya.father = vitya
tanya.mother = nadya

nadya.mother = valya
nadya.brother = [misha]
misha.sister = [nadya,nina]
nadya.sister = [nina]

fedya.sister = [olya]
fedya.animal = [bobik]
olya.brother = [fedya]
olya.animal = [gora,kesha]
fedya.father = misha
olya.father = misha


vitya.father = alex1
kolya.father = alex1
vitya.brother = [kolya]
kolya.brother = [vitya]
elena.father = kolya
elena.brother = [alex2]
alex2.father = kolya
alex2.sister = [elena]
var family:[Human] = [sasha,tanya,vitya,nadya,valya,misha,olya,fedya,nina,kolya,elena,alex1,alex2]

func count (_ name: Human) {
    var countUncle = 0
    var countAunt = 0
    var countBrother2 = 0
    var countSister2 = 0
    
    func manWoman (_ relative: Human) -> Bool {
        if relative is Man {
            return true
        } else {
              return false
            }
    }
    
    //Count Uncle
    if let uncle = name.mother?.brother {
        countUncle += uncle.count
    }
    if let uncle = name.father?.brother {
        countUncle += uncle.count
    }
    //Count Aunt
    if let aunt = name.mother?.sister {
        countAunt += aunt.count
    }
    if let aunt = name.father?.sister {
        countAunt += aunt.count
    }
    for relative in family {
        if let father = name.father {
            if let uncle = relative.mother?.brother {
                if uncle.contains(where: { (human) -> Bool in
                    father === human
                })
                {
                    if manWoman(relative) {
                        countBrother2 += 1
                    } else {
                        countSister2 += 1
                    }
                }
            }
            if let uncle = relative.father?.brother {
                if uncle.contains(where: { (human) -> Bool in
                    father === human
                })
                {
                    if manWoman(relative) {
                      countBrother2 += 1
                    } else {
                       countSister2 += 1
                    }
                }
            }
        }
        if let mother = name.mother {
            if let aunt = relative.mother?.sister {
                if aunt.contains(where: { (human) -> Bool in
                    mother === human
                })
                {
                    if manWoman(relative) {
                    countBrother2 += 1
                } else {
                    countSister2 += 1
                    }
                }
            }
            if let aunt = relative.father?.sister {
                if aunt.contains(where: { (human) -> Bool in
                    mother === human
                })
                {
                    if manWoman(relative) {
                        countBrother2 += 1
                    } else {
                        countSister2 += 1
                    }
                }
            }
        }
       
    }

    print("\(name.name) uncle count: \(countUncle)")
    print("\(name.name) aunt count: \(countAunt)")
    print("\(name.name) brother cousin count: \(countBrother2)")
    print("\(name.name) sister cousin count: \(countSister2)")
    
    }

  count(tanya)
var countMan = 0
var countWoman = 0
for relative in family {
    if relative is Man {
        countMan += 1
    }
    if relative is Woman {
        countWoman += 1
    }
    if let man = relative as? Man {
        man.move()
    }
    if let woman = relative as? Woman {
        woman.tellMove()
    }
}

print("Count Man: \(countMan)")
print("Count Woman: \(countWoman)")



var animal = [Animal]()
var countCat = 0
var countDog = 0
var countParrot = 0
var countPig = 0

for human in family {
    if let humanAnimal = human.animal {
       animal += humanAnimal
    }
}
animal
for animal in animal {
    animal.call()
    if animal is Cat {
        countCat += 1
    }
    if animal is Dog {
        countDog += 1
    }
    if animal is Parrot {
        countParrot += 1
    }
    if animal is Pig {
        countPig += 1
    }
}
print("Count cat: \(countCat), Count dog: \(countDog), Count parrot: \(countParrot), Count Pig: \(countPig),")
