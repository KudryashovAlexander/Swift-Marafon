
/*
 Сделаем с вами небольшую игру

1. Создайте тип Комната. У комнаты есть размеры W на H. И создайте тип Персонаж. У негоесть координата в комнате X и Y. Реализуйте функцию, которая красивенько текстом будет показывать положение персонажа в комнате

2. Персонажу добавьте метод идти, который принимает энумчик лево, право, верх, вниз
Этот метод должен передвигать персонажа. Реализуйте правило что персонаж не должен покинуть пределы комнаты. Подвигайте персонажа и покажите это графически

3. Создать тип Ящик. У ящика также есть координата в комнате X и Y. Ящик также не может покидать пределы комнаты и ящик также должен быть распечатан вместе с персонажем в функции печати.

4. Теперь самое интересное, персонаж может двигать ящик, если он стоит на том месте, куда персонаж хочет попасть. Главное что ни один объект не может покинуть пределы комнаты. Подвигайте ящик :)

5. Добавьте точку в комнате, куда надо ящик передвинуть и двигайте :)

Для суперменов: можете добавить массив ящиков и можете сделать консольное приложение
*/

//исходные данные
var player = "\u{1F697}"
var object = "\u{1F6A7}"
var complate = "\u{1F6A9}"
var blackBlock = "\u{2B1B}"
var whiteBlock = "\u{2B1C}"

class Subject{
    var x: Int {
        didSet {
            if x < 2 {
               x = oldValue
            }
        }
    }
    var y: Int{
        didSet {
            if y < 2 {
                y = oldValue
            }
        }
    }
    init (x:Int, y:Int) {
        self.x = x < 2 ? 2 : x
        self.y = y < 2 ? 2 : y
    }
}
// из второго пункта
enum Move{
    case Up
    case Down
    case Left
    case Right
}

class Room {
    var length:Int {
        didSet {
            if length < 0{
                length = oldValue
            }
        }
        
    }
    var width:Int{
        didSet {
            if width < 0{
                width = oldValue
            }
        }
    }
    lazy var person = Subject (x: 0, y: 0)
    lazy var box = Subject (x: 0, y: 0)
    lazy var finish = Subject (x: 0, y: 0)
    
    init (length:Int, width:Int) {
        self.length = length < 1 ? 1 : length
        self.width  = width < 1 ? 1 : width
    }
    func printRoom () {
        for i in 1...width {
            var str = ""
            for j in 1...length {
                switch (i,j) {
                case (i,j) where i==1 || j==1 || i==length || j==width : str += blackBlock
                case (person.x,person.y): str += player
                case (box.x,box.y): str += object
                case (finish.x,finish.y): str += complate
                default: str += whiteBlock
                }
            }
            print (str)
        }
    }
    func movePlayer(move:Move) {
        let perPerson = Subject(x: person.x, y: person.y)
        switch move {
        case .Up: if person.x < (width - 1) { person.x += 1 }
        case .Down: person.x -= 1
        case .Left: person.y -= 1
        case.Right: if person.y < (length - 1 ) { person.y += 1 }
        }
        if (person.x,person.y) == (box.x,box.y) {
            let isMove = moveBox(move:move)
            if !isMove {
                person = perPerson
            }
        }
    }
    
    func moveBox(move:Move) -> Bool {
        let perBox = Subject(x: box.x, y: box.y)
            switch move {
            case .Up: if box.x < (width - 1) { box.x += 1 }
            case .Down: box.x -= 1
            case .Left: box.y -= 1
            case.Right: if box.y < (length - 1) { box.y += 1 }
            }
        if (perBox.x,perBox.y) == (box.x,box.y) {
            return false
        }
        return true
        }
    
}

    
var level1 = Room(length: 10, width: 10)
level1.finish = Subject(x: 7, y: 7)
level1.person = Subject(x: 4, y: 2)
level1.box = Subject(x: 3, y: 3)
level1.printRoom()
level1.movePlayer(move: .Down)
level1.printRoom()
level1.movePlayer(move: .Right)
level1.printRoom()
level1.movePlayer(move: .Right)
level1.printRoom()
level1.movePlayer(move: .Right)
level1.printRoom()
level1.movePlayer(move: .Right)
level1.printRoom()
level1.movePlayer(move: .Right)
level1.printRoom()
level1.movePlayer(move: .Right)
level1.printRoom()
level1.movePlayer(move: .Right)
level1.printRoom()

