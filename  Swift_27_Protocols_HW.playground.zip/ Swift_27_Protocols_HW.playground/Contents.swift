//Домашнее задание Алексея Скутуренко: Протоколы часть 1
/*
1. Объявить протокол Food, который будет иметь проперти name (только чтение) и метод taste(), который будет выводить текст со вкусовыми ощущениями

2. Все продукты разных типов, которые вы принесли из супермаркета, находятся в сумке (массив) и все, как ни странно, реализуют протокол Food. Вам нужно пройтись по сумке, назвать предмет и откусить кусочек. Можете отсортировать продукты до имени. Используйте для этого отдельную функцию, которая принимает массив продуктов

3. Некоторые продукты могут испортиться, если их не положить в холодильник. Создайте новый протокол Storable, он наследуется от протокола Food и содержит еще булевую проперти - expired. У некоторых продуктов замените Food на Storable. Теперь пройдитесь по всем продуктам и, если продукт надо хранить в холодильнике, то перенесите его туда, но только если продукт не испорчен уже, иначе просто избавьтесь от него. Используйте функцию для вывода продуктов для вывода содержимого холодильника

4. Добавьте проперти daysToExpire в протокол Storable. Отсортируйте массив продуктов в холодильнике. Сначала пусть идут те, кто быстрее портятся. Если срок совпадает, то сортируйте по имени.

5. Не все, что мы кладем в холодильник, является едой. Поэтому сделайте так, чтобы Storable не наследовался от Food. Мы по прежнему приносим еду домой, но некоторые продукты реализуют теперь 2 протокола. Холодильник принимает только те продукты, которые еще и Storable. функция сортировки должна по прежнему работать.
*/

protocol Food {
    var name : String { get }
    func taste() -> String
}
protocol Storable {
    var name : String { get }
    var expired : Bool { get }
    var daysToExpire: Int { get }
}



class Apple: Food {
    var name : String = "Apple"
    func taste() -> String {
        return "very Good"
    }
}
class Fish: Storable, Food {
    var name = "Fish"
    func taste() -> String {
        return "good"
    }
    var expired = false
    var daysToExpire = 20
}
class Mean: Storable, Food {
    var name = "Mean"
    func taste() -> String {
        return "not Bad"
    }
    var expired = false
    var daysToExpire = 20
}

class Milk: Storable, Food {
    var name = "Milk"
    func taste() -> String {
        return "normal"
    }
    var expired = true
    var daysToExpire = 2
}
class Pepper: Food {
    var name = "Pepper"
    func taste() -> String {
        return "bad"
    }
}
class Сheese: Storable, Food {
    var name = "Cheese"
    func taste() -> String {
        return "not bad"
    }
    var expired = false
    var daysToExpire = 30
}

class Butter: Food {
    var name = "Butter"
    func taste() -> String {
        return "Normal"
    }
}
class Paper: Storable {
    var name = "Paper"
    var expired = true
    var daysToExpire = 30
}


//Создаем продукты
var apple = Apple()
var fish = Fish()
var mean = Mean()
var milk = Milk()
var pepper = Pepper()
var cheese = Сheese()
var butter = Butter()
var paper = Paper()

//Создаем массив
var arrayProducts: [Food] = [fish, mean, milk, pepper, apple, cheese, butter]

//Фунция сортировки массива по имени
func sort( _ array: [Food]) -> [Food] {
    let arraySort = array.sorted { $0.name.lowercased() < $1.name.lowercased() }
    return arraySort
}
arrayProducts = sort(arrayProducts)

//Вывод всех продуктов и их оценка
for product in arrayProducts {
    print ("\(product.name) is \(product.taste())")
}

//Проверка продуктов на испорченность
var fridge: [Storable] = []
for product in arrayProducts {
    if let storable = product as? Storable {
        if storable.expired == false {
            fridge.append(storable)
        } else {
            print ("\(storable.name) deleate")
        }
    }
}
fridge


fridge.append(paper)

//Функция сортировки продуктов в холодильнике
func sortFridge( _ array: [Storable]) -> [Storable] {
    let arraySort = array.sorted { ($0.daysToExpire, $0.name.lowercased()) < ($1.daysToExpire, $1.name.lowercased()) }
    return arraySort
}
 sortFridge(fridge)
